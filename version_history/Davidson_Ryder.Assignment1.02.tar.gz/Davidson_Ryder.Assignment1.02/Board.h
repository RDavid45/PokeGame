#ifndef BOARD_H
#define BOARD_H

typedef struct Map Map;

typedef struct Board 
{
    char board[21][80];
    int height;
    int width;
    int left;
    int top;
    int right;
    int bottom;
} Board;


int genBoard(Map *m);
int printBoard(Board *b);


#endif
