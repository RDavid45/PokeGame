#ifndef BOARD_H
#define BOARD_H

typedef struct Board 
{
    char board[21][80];
    int height;
    int width;
    int left;
    int top;
    int right;
    int bottom;
} Board;


int genBoard(Board *b);
int genBoardConnected(Board *b, int n, int s, int w, int e);
int printBoard(Board *b);


#endif