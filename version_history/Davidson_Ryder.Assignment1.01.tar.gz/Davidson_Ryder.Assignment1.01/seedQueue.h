#ifndef SEEDQUEUE_H
#define SEEDQUEUE_H

struct seed
{
    int x;
    int y;
    char chr;
    struct seed *next;
};
struct seedQueue{
    struct seed *front;
    struct seed *back;
    int size;
};

int initSeedQueue(struct seedQueue *q);
int destroySeedQueue(struct seedQueue *q);
int enqueueSeed(struct seedQueue *q, int x, int y, char c);
int dequeueSeed(struct seedQueue *q, int *x, int *y, char *c);
int peekSeedQueue(struct seedQueue *q, int *x, int *y, char *c);
int sizeQueue(struct seedQueue *q, int *size);
int isEmptyQueue(struct seedQueue *q);




#endif